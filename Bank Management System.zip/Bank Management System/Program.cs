using System;
using System.Collections.Generic;
using System.Threading;

namespace BankManagementSystem
{
    class Program
    {
        // ============================================================
        // GLOBAL VARIABLES - Store ALL accounts using parallel Lists
        // Each index represents one account (isolated from others)
        // ============================================================
        static List<string> allNames = new List<string>();
        static List<int> allAges = new List<int>();
        static List<string> allAccountNumbers = new List<string>();
        static List<double> allBalances = new List<double>();
        static List<string> allPasswords = new List<string>();
        static List<string> allStatuses = new List<string>();
        static List<List<string>> allTransactions = new List<List<string>>();

        // Session state - tracks which account is currently active
        static int currentAccount = -1; // -1 = no account selected
        static bool isLoggedIn = false;

        // ============================================================
        // MAIN ENTRY POINT
        // ============================================================
        static void Main(string[] args)
        {
            // Set console title
            Console.Title = "🏦 Bank Management System";

            // Show welcome screen
            ShowWelcomeScreen();

            // Keep the program running until user exits
            bool running = true;

            while (running)
            {
                // Show main menu and get user choice
                int choice = ShowMainMenu();

                // Process user choice using switch case
                switch (choice)
                {
                    case 1:
                        CreateNewAccount();
                        break;
                    case 2:
                        LoginScreen();
                        break;
                    case 3:
                        DepositMoney();
                        break;
                    case 4:
                        WithdrawMoney();
                        break;
                    case 5:
                        CheckBalance();
                        break;
                    case 6:
                        TransferMoney();
                        break;
                    case 7:
                        AccountInformation();
                        break;
                    case 8:
                        TransactionHistory();
                        break;
                    case 9:
                        LogoutAccount();
                        break;
                    case 10:
                        running = ExitSystem();
                        break;
                    default:
                        PrintError("Invalid option! Please enter a number between 1 and 10.");
                        PauseScreen();
                        break;
                }
            }
        }

        // ============================================================
        // METHOD: Show Welcome Screen with Animation
        // ============================================================
        static void ShowWelcomeScreen()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;

            // Loading animation using a loop
            string loadingText = "Initializing Bank System";
            Console.Write("\n\n\t" + loadingText);
            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(500);
                Console.Write(".");
            }
            Thread.Sleep(400);

            Console.Clear();

            // Welcome banner
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n");
            Console.WriteLine("\t╔══════════════════════════════════════════════════╗");
            Console.WriteLine("\t║                                                  ║");
            Console.WriteLine("\t║        🏦  BANK MANAGEMENT SYSTEM  🏦           ║");
            Console.WriteLine("\t║                                                  ║");
            Console.WriteLine("\t║         Secure | Reliable | Professional        ║");
            Console.WriteLine("\t║                                                  ║");
            Console.WriteLine("\t╚══════════════════════════════════════════════════╝");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("\n\t         Press any key to continue...\n");
            Console.ResetColor();
            Console.ReadKey();
        }

        // ============================================================
        // METHOD: Show Main Menu and Return User Choice
        // ============================================================
        static int ShowMainMenu()
        {
            Console.Clear();

            // Header
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n\t╔══════════════════════════════════════════════════╗");
            Console.WriteLine("\t║           🏦  BANK MANAGEMENT SYSTEM             ║");
            Console.WriteLine("\t╠══════════════════════════════════════════════════╣");

            // Show account status if logged in
            if (isLoggedIn && currentAccount >= 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\t║  👤 Welcome, {allNames[currentAccount],-36}║");
                Console.WriteLine($"\t║  💰 Balance: ${allBalances[currentAccount],-35:F2}║");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\t╠══════════════════════════════════════════════════╣");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine($"\t║  🔒 No account logged in | {allNames.Count} account(s) created ║");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\t╠══════════════════════════════════════════════════╣");
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t║                   MAIN MENU                      ║");
            Console.WriteLine("\t╠══════════════════════════════════════════════════╣");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t║   1.  📝  Create New Account                     ║");
            Console.WriteLine("\t║   2.  🔐  Login to Account                       ║");
            Console.WriteLine("\t║   3.  💵  Deposit Money                          ║");
            Console.WriteLine("\t║   4.  💸  Withdraw Money                         ║");
            Console.WriteLine("\t║   5.  💰  Check Balance                          ║");
            Console.WriteLine("\t║   6.  🔄  Transfer Money                         ║");
            Console.WriteLine("\t║   7.  👤  Account Information                    ║");
            Console.WriteLine("\t║   8.  📋  Transaction History                    ║");
            Console.WriteLine("\t║   9.  🔓  Logout / Switch Account                ║");
            Console.WriteLine("\t║  10.  🚪  Exit                                   ║");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t╚══════════════════════════════════════════════════╝");
            Console.ResetColor();

            Console.Write("\n\t➤  Enter your choice (1-10): ");
            Console.ForegroundColor = ConsoleColor.Green;

            // Validate menu input
            string input = Console.ReadLine();
            Console.ResetColor();

            int choice;
            if (int.TryParse(input, out choice))
            {
                return choice;
            }
            else
            {
                return -1; // Invalid input
            }
        }

        // ============================================================
        // METHOD: Login Screen with Password Protection
        // ============================================================
        static void LoginScreen()
        {
            Console.Clear();
            PrintHeader("🔐  SECURE LOGIN");

            if (allNames.Count == 0)
            {
                PrintWarning("No accounts exist yet. Please create an account first (Option 1).");
                PauseScreen();
                return;
            }

            if (isLoggedIn)
            {
                PrintWarning($"You are already logged in as {allNames[currentAccount]} ({allAccountNumbers[currentAccount]}).");
                PrintWarning("Please logout first (Option 9) to switch accounts.");
                PauseScreen();
                return;
            }

            int attempts = 0;
            int maxAttempts = 3;

            while (attempts < maxAttempts)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\n\t  Enter Account Number : ");
                Console.ForegroundColor = ConsoleColor.Green;
                string inputAccount = Console.ReadLine();

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Enter Password       : ");
                Console.ForegroundColor = ConsoleColor.Green;
                string inputPassword = ReadPassword(); // Masked input
                Console.ResetColor();

                // Search through all accounts to find matching credentials
                bool found = false;
                for (int i = 0; i < allAccountNumbers.Count; i++)
                {
                    if (inputAccount == allAccountNumbers[i] && inputPassword == allPasswords[i])
                    {
                        currentAccount = i;
                        isLoggedIn = true;
                        found = true;
                        PrintSuccess("Login successful! Welcome back, " + allNames[i] + "!");
                        Thread.Sleep(1200);
                        return;
                    }
                }

                if (!found)
                {
                    attempts++;
                    int remaining = maxAttempts - attempts;
                    if (remaining > 0)
                        PrintError($"Invalid credentials! {remaining} attempt(s) remaining.");
                    else
                        PrintError("Too many failed attempts! Please try again later.");
                }
            }

            PrintWarning("Returning to main menu...");
            Thread.Sleep(1500);
        }

        // ============================================================
        // METHOD: Create New Account
        // ============================================================
        static void CreateNewAccount()
        {
            Console.Clear();
            PrintHeader("📝  CREATE NEW ACCOUNT");

            // Show how many accounts already exist
            if (allNames.Count > 0)
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine($"\n\t  ℹ️  {allNames.Count} account(s) already exist in this session.");
                Console.ResetColor();
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\t  Please fill in the following details:\n");

            // --- Full Name ---
            string name = "";
            while (true)
            {
                Console.Write("\t  Full Name        : ");
                Console.ForegroundColor = ConsoleColor.Green;
                name = Console.ReadLine().Trim();
                Console.ResetColor();

                if (name.Length >= 2)
                    break;
                else
                    PrintError("Name must be at least 2 characters. Please try again.");
            }

            // --- Age ---
            int age = 0;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Age              : ");
                Console.ForegroundColor = ConsoleColor.Green;
                string ageInput = Console.ReadLine();
                Console.ResetColor();

                if (int.TryParse(ageInput, out age) && age >= 18 && age <= 100)
                    break;
                else
                    PrintError("Age must be a number between 18 and 100.");
            }

            // --- Account Number ---
            string accNum = "";
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Account Number   : ");
                Console.ForegroundColor = ConsoleColor.Green;
                accNum = Console.ReadLine().Trim();
                Console.ResetColor();

                // Validate: must be exactly 10 digits
                bool isValid = true;
                if (accNum.Length != 10)
                    isValid = false;
                else
                {
                    foreach (char c in accNum)
                    {
                        if (!char.IsDigit(c))
                        {
                            isValid = false;
                            break;
                        }
                    }
                }

                if (!isValid)
                {
                    PrintError("Account number must be exactly 10 digits (numbers only).");
                    continue;
                }

                // Check if account number already taken
                bool duplicate = false;
                for (int i = 0; i < allAccountNumbers.Count; i++)
                {
                    if (allAccountNumbers[i] == accNum)
                    {
                        duplicate = true;
                        break;
                    }
                }
                if (duplicate)
                {
                    PrintError("This account number is already taken! Choose a different one.");
                    continue;
                }

                break;
            }

            // --- Initial Balance ---
            double initialBalance = 0.0;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Initial Deposit  : $");
                Console.ForegroundColor = ConsoleColor.Green;
                string balInput = Console.ReadLine();
                Console.ResetColor();

                if (double.TryParse(balInput, out initialBalance) && initialBalance >= 100.0)
                    break;
                else
                    PrintError("Initial deposit must be at least $100.00.");
            }

            // --- Password ---
            string password = "";
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Set Password     : ");
                Console.ForegroundColor = ConsoleColor.Green;
                string pass1 = ReadPassword();
                Console.ResetColor();

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Confirm Password : ");
                Console.ForegroundColor = ConsoleColor.Green;
                string pass2 = ReadPassword();
                Console.ResetColor();

                if (pass1 == pass2 && pass1.Length >= 4)
                {
                    password = pass1;
                    break;
                }
                else if (pass1.Length < 4)
                    PrintError("Password must be at least 4 characters.");
                else
                    PrintError("Passwords do not match. Try again.");
            }

            // --- Save Account Data to Lists ---
            allNames.Add(name);
            allAges.Add(age);
            allAccountNumbers.Add(accNum);
            allBalances.Add(initialBalance);
            allPasswords.Add(password);
            allStatuses.Add("Active");
            List<string> newHistory = new List<string>();
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            newHistory.Add($"[{timestamp}] ✅ Account Created | Initial Deposit: ${initialBalance:F2}");
            allTransactions.Add(newHistory);

            // Auto-login to the new account
            currentAccount = allNames.Count - 1;
            isLoggedIn = true;

            // Success animation
            ShowLoadingAnimation("Creating your account");

            // Confirmation
            Console.Clear();
            PrintHeader("✅  ACCOUNT CREATED SUCCESSFULLY");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n\t  👤  Account Holder : {name}");
            Console.WriteLine($"\t  🔢  Account Number : {accNum}");
            Console.WriteLine($"\t  💰  Opening Balance: ${initialBalance:F2}");
            Console.WriteLine($"\t  📅  Created On     : {timestamp}");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\t  ⚠️  Please remember your account number and password!");
            Console.WriteLine($"\t  ℹ️  Total accounts in session: {allNames.Count}");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Deposit Money
        // ============================================================
        static void DepositMoney()
        {
            Console.Clear();
            PrintHeader("💵  DEPOSIT MONEY");

            // Check if account exists and is logged in
            if (!CheckAccountAccess()) return;

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\n\t  Current Balance: ${allBalances[currentAccount]:F2}");
            Console.WriteLine("\n\t  Enter deposit amount (minimum $1.00):");
            Console.Write("\t  Amount: $");
            Console.ForegroundColor = ConsoleColor.Green;
            string input = Console.ReadLine();
            Console.ResetColor();

            double amount;

            // Validate deposit amount using logical operators
            if (!double.TryParse(input, out amount) || amount <= 0)
            {
                PrintError("Invalid amount! Please enter a positive number.");
                PauseScreen();
                return;
            }

            if (amount < 1.0)
            {
                PrintError("Minimum deposit amount is $1.00.");
                PauseScreen();
                return;
            }

            if (amount > 1000000)
            {
                PrintError("Maximum single deposit is $1,000,000.");
                PauseScreen();
                return;
            }

            // Add amount to balance using arithmetic operator
            double previousBalance = allBalances[currentAccount];
            allBalances[currentAccount] += amount;

            // Log transaction
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            allTransactions[currentAccount].Add($"[{timestamp}] 💵 Deposit      | Amount: +${amount:F2} | Balance: ${allBalances[currentAccount]:F2}");

            // Show loading animation
            ShowLoadingAnimation("Processing deposit");

            // Show success message
            Console.Clear();
            PrintHeader("✅  DEPOSIT SUCCESSFUL");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n\t  💵  Amount Deposited : ${amount:F2}");
            Console.WriteLine($"\t  📊  Previous Balance : ${previousBalance:F2}");
            Console.WriteLine($"\t  💰  New Balance      : ${allBalances[currentAccount]:F2}");
            Console.WriteLine($"\t  📅  Transaction Date : {timestamp}");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Withdraw Money
        // ============================================================
        static void WithdrawMoney()
        {
            Console.Clear();
            PrintHeader("💸  WITHDRAW MONEY");

            if (!CheckAccountAccess()) return;

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\n\t  Current Balance: ${allBalances[currentAccount]:F2}");
            Console.WriteLine("\n\t  Enter withdrawal amount:");
            Console.Write("\t  Amount: $");
            Console.ForegroundColor = ConsoleColor.Green;
            string input = Console.ReadLine();
            Console.ResetColor();

            double amount;

            // Validate withdrawal amount
            if (!double.TryParse(input, out amount) || amount <= 0)
            {
                PrintError("Invalid amount! Please enter a positive number.");
                PauseScreen();
                return;
            }

            // Check for sufficient balance using comparison operator
            if (amount > allBalances[currentAccount])
            {
                PrintError($"Insufficient funds! Your balance is ${allBalances[currentAccount]:F2}.");
                PrintWarning($"You tried to withdraw ${amount:F2}.");
                PauseScreen();
                return;
            }

            if (amount < 1.0)
            {
                PrintError("Minimum withdrawal amount is $1.00.");
                PauseScreen();
                return;
            }

            // Deduct amount using arithmetic operator
            double previousBalance = allBalances[currentAccount];
            allBalances[currentAccount] -= amount;

            // Log transaction
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            allTransactions[currentAccount].Add($"[{timestamp}] 💸 Withdrawal   | Amount: -${amount:F2} | Balance: ${allBalances[currentAccount]:F2}");

            ShowLoadingAnimation("Processing withdrawal");

            Console.Clear();
            PrintHeader("✅  WITHDRAWAL SUCCESSFUL");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n\t  💸  Amount Withdrawn : ${amount:F2}");
            Console.WriteLine($"\t  📊  Previous Balance : ${previousBalance:F2}");
            Console.WriteLine($"\t  💰  Remaining Balance: ${allBalances[currentAccount]:F2}");
            Console.WriteLine($"\t  📅  Transaction Date : {timestamp}");

            // Low balance warning
            if (allBalances[currentAccount] < 100)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n\t  ⚠️  Warning: Your balance is below $100.00!");
            }
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Check Balance
        // ============================================================
        static void CheckBalance()
        {
            Console.Clear();
            PrintHeader("💰  ACCOUNT BALANCE");

            if (!CheckAccountAccess()) return;

            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\t  ┌─────────────────────────────────────────┐");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\t  │  Account Holder : {allNames[currentAccount],-23}│");
            Console.WriteLine($"\t  │  Account Number : {allAccountNumbers[currentAccount],-23}│");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t  ├─────────────────────────────────────────┤");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\t  │  Current Balance: ${allBalances[currentAccount],-22:F2}│");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t  ├─────────────────────────────────────────┤");

            // Balance status using if-else
            string balanceStatus;
            ConsoleColor statusColor;
            if (allBalances[currentAccount] >= 10000)
            {
                balanceStatus = "Excellent 🌟";
                statusColor = ConsoleColor.Green;
            }
            else if (allBalances[currentAccount] >= 1000)
            {
                balanceStatus = "Good ✅";
                statusColor = ConsoleColor.Cyan;
            }
            else if (allBalances[currentAccount] >= 100)
            {
                balanceStatus = "Fair ⚠️";
                statusColor = ConsoleColor.Yellow;
            }
            else
            {
                balanceStatus = "Low ❗";
                statusColor = ConsoleColor.Red;
            }

            Console.ForegroundColor = statusColor;
            Console.WriteLine($"\t  │  Balance Status : {balanceStatus,-23}│");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\t  │  Checked On     : {timestamp,-23}│");
            Console.WriteLine("\t  └─────────────────────────────────────────┘");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Transfer Money
        // ============================================================
        static void TransferMoney()
        {
            Console.Clear();
            PrintHeader("🔄  TRANSFER MONEY");

            if (!CheckAccountAccess()) return;

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\n\t  Your Balance: ${allBalances[currentAccount]:F2}");
            Console.WriteLine("\n\t  ─────────────────────────────────────────");
            Console.WriteLine("\t  Transfer between accounts in this session");
            Console.WriteLine("\t  or to external account numbers.");
            Console.WriteLine("\t  ─────────────────────────────────────────\n");

            // Get target account number
            string targetAccount = "";
            while (true)
            {
                Console.Write("\t  Target Account Number: ");
                Console.ForegroundColor = ConsoleColor.Green;
                targetAccount = Console.ReadLine().Trim();
                Console.ResetColor();

                // Validate: must be 10 digits and different from own account
                bool validFormat = targetAccount.Length == 10;
                if (validFormat)
                {
                    foreach (char c in targetAccount)
                    {
                        if (!char.IsDigit(c))
                        {
                            validFormat = false;
                            break;
                        }
                    }
                }

                if (!validFormat)
                {
                    PrintError("Account number must be exactly 10 digits.");
                    continue;
                }

                // Cannot transfer to own account
                if (targetAccount == allAccountNumbers[currentAccount])
                {
                    PrintError("Cannot transfer to your own account.");
                    continue;
                }

                break;
            }

            // Get transfer amount
            double amount = 0;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\t  Transfer Amount: $");
                Console.ForegroundColor = ConsoleColor.Green;
                string input = Console.ReadLine();
                Console.ResetColor();

                if (!double.TryParse(input, out amount) || amount <= 0)
                {
                    PrintError("Please enter a valid positive amount.");
                    continue;
                }

                if (amount > allBalances[currentAccount])
                {
                    PrintError($"Insufficient balance! Available: ${allBalances[currentAccount]:F2}");
                    continue;
                }

                if (amount < 1.0)
                {
                    PrintError("Minimum transfer amount is $1.00.");
                    continue;
                }

                break;
            }

            // Confirm transfer
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n\t  ⚠️  Confirm Transfer:");
            Console.WriteLine($"\t  From : {allAccountNumbers[currentAccount]}");
            Console.WriteLine($"\t  To   : {targetAccount}");
            Console.WriteLine($"\t  Amount: ${amount:F2}");
            Console.Write("\n\t  Proceed? (yes/no): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string confirm = Console.ReadLine().Trim().ToLower();
            Console.ResetColor();

            if (confirm != "yes" && confirm != "y")
            {
                PrintWarning("Transfer cancelled.");
                PauseScreen();
                return;
            }

            // Execute transfer
            double previousBalance = allBalances[currentAccount];
            allBalances[currentAccount] -= amount;

            // If target account exists in session, credit it
            for (int i = 0; i < allAccountNumbers.Count; i++)
            {
                if (allAccountNumbers[i] == targetAccount)
                {
                    allBalances[i] += amount;
                    allTransactions[i].Add($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] 🔄 Transfer In  | Amount: +${amount:F2} | From: {allAccountNumbers[currentAccount]} | Balance: ${allBalances[i]:F2}");
                    break;
                }
            }

            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            allTransactions[currentAccount].Add($"[{timestamp}] 🔄 Transfer Out | Amount: -${amount:F2} | To: {targetAccount} | Balance: ${allBalances[currentAccount]:F2}");

            ShowLoadingAnimation("Processing transfer");

            Console.Clear();
            PrintHeader("✅  TRANSFER SUCCESSFUL");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n\t  🔄  Amount Transferred: ${amount:F2}");
            Console.WriteLine($"\t  📤  From Account     : {allAccountNumbers[currentAccount]}");
            Console.WriteLine($"\t  📥  To Account       : {targetAccount}");
            Console.WriteLine($"\t  📊  Previous Balance : ${previousBalance:F2}");
            Console.WriteLine($"\t  💰  Remaining Balance: ${allBalances[currentAccount]:F2}");
            Console.WriteLine($"\t  📅  Transaction Date : {timestamp}");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Account Information
        // ============================================================
        static void AccountInformation()
        {
            Console.Clear();
            PrintHeader("👤  ACCOUNT INFORMATION");

            if (!CheckAccountAccess()) return;

            string creationDate = "N/A";
            if (allTransactions[currentAccount].Count > 0)
            {
                // Extract date from first transaction
                string firstTx = allTransactions[currentAccount][0];
                if (firstTx.Length > 21)
                    creationDate = firstTx.Substring(1, 19);
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\t  ╔═════════════════════════════════════════════╗");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t  ║           ACCOUNT DETAILS                   ║");
            Console.WriteLine("\t  ╠═════════════════════════════════════════════╣");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\t  ║  👤 Name    : {allNames[currentAccount],-30}║");
            Console.WriteLine($"\t  ║  🎂 Age     : {allAges[currentAccount],-30}║");
            Console.WriteLine($"\t  ║  🔢 Acc No  : {allAccountNumbers[currentAccount],-30}║");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\t  ║  💰 Balance : ${allBalances[currentAccount],-29:F2}║");
            Console.ForegroundColor = ConsoleColor.White;

            // Determine and display account status
            ConsoleColor statusColor = allStatuses[currentAccount] == "Active" ? ConsoleColor.Green : ConsoleColor.Red;
            Console.Write("\t  ║  📌 Status  : ");
            Console.ForegroundColor = statusColor;
            Console.Write($"{allStatuses[currentAccount],-30}");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("║");

            Console.WriteLine($"\t  ║  📅 Created : {creationDate,-30}║");
            Console.WriteLine($"\t  ║  📊 Txn Count: {allTransactions[currentAccount].Count,-29}║");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t  ╚═════════════════════════════════════════════╝");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Transaction History
        // ============================================================
        static void TransactionHistory()
        {
            Console.Clear();
            PrintHeader("📋  TRANSACTION HISTORY");

            if (!CheckAccountAccess()) return;

            if (allTransactions[currentAccount].Count == 0)
            {
                PrintWarning("No transactions found for this account.");
                PauseScreen();
                return;
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\n\t  Account: {allAccountNumbers[currentAccount]} | Total Transactions: {allTransactions[currentAccount].Count}");
            Console.WriteLine("\t  ─────────────────────────────────────────────────────────");

            // Loop through all transactions and display them
            for (int i = 0; i < allTransactions[currentAccount].Count; i++)
            {
                string tx = allTransactions[currentAccount][i];

                // Color code based on transaction type
                if (tx.Contains("Deposit") || tx.Contains("Created"))
                    Console.ForegroundColor = ConsoleColor.Green;
                else if (tx.Contains("Withdrawal"))
                    Console.ForegroundColor = ConsoleColor.Red;
                else if (tx.Contains("Transfer"))
                    Console.ForegroundColor = ConsoleColor.Yellow;
                else
                    Console.ForegroundColor = ConsoleColor.White;

                Console.WriteLine($"\t  {i + 1,2}. {tx}");
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t  ─────────────────────────────────────────────────────────");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\t  Current Balance: ${allBalances[currentAccount]:F2}");
            Console.ResetColor();

            PauseScreen();
        }

        // ============================================================
        // METHOD: Exit System
        // ============================================================
        static bool ExitSystem()
        {
            Console.Clear();
            PrintHeader("🚪  EXIT SYSTEM");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t  Are you sure you want to exit? (yes/no): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string confirm = Console.ReadLine().Trim().ToLower();
            Console.ResetColor();

            if (confirm == "yes" || confirm == "y")
            {
                ShowLoadingAnimation("Logging out securely");

                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n\n\t╔══════════════════════════════════════════════════╗");
                Console.WriteLine("\t║                                                  ║");
                Console.WriteLine("\t║     Thank you for using Bank Management System   ║");
                Console.WriteLine("\t║                                                  ║");
                Console.WriteLine("\t║          Have a safe and wonderful day! 😊       ║");
                Console.WriteLine("\t║                                                  ║");
                Console.WriteLine("\t╚══════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                Thread.Sleep(2000);
                return false; // Stop the main loop
            }
            else
            {
                PrintSuccess("Exit cancelled. Welcome back!");
                PauseScreen();
                return true; // Keep running
            }
        }

        // ============================================================
        // HELPER METHODS
        // ============================================================

        // Check if account is created and user is logged in
        static bool CheckAccountAccess()
        {
            if (allNames.Count == 0)
            {
                PrintError("No account found! Please create an account first (Option 1).");
                PauseScreen();
                return false;
            }
            if (!isLoggedIn || currentAccount < 0)
            {
                PrintError("You must be logged in to perform this action (Option 2).");
                PauseScreen();
                return false;
            }
            return true;
        }

        // ============================================================
        // METHOD: Logout / Switch Account
        // ============================================================
        static void LogoutAccount()
        {
            Console.Clear();
            PrintHeader("🔓  LOGOUT / SWITCH ACCOUNT");

            if (!isLoggedIn)
            {
                PrintWarning("You are not logged in to any account.");
                PauseScreen();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n\t  Currently logged in as: {allNames[currentAccount]}");
            Console.WriteLine($"\t  Account Number: {allAccountNumbers[currentAccount]}");
            Console.Write("\n\t  Are you sure you want to logout? (yes/no): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string confirm = Console.ReadLine().Trim().ToLower();
            Console.ResetColor();

            if (confirm == "yes" || confirm == "y")
            {
                string name = allNames[currentAccount];
                currentAccount = -1;
                isLoggedIn = false;
                PrintSuccess($"Logged out from {name}'s account successfully!");
                PrintSuccess($"You can now login to another account (Option 2) or create a new one (Option 1).");
            }
            else
            {
                PrintSuccess("Logout cancelled. You are still logged in.");
            }

            PauseScreen();
        }

        // Print formatted header
        static void PrintHeader(string title)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n\t╔══════════════════════════════════════════════════╗");
            // Center the title
            int padding = (50 - title.Length) / 2;
            string centered = title.PadLeft(title.Length + padding).PadRight(50);
            Console.WriteLine($"\t║{centered}║");
            Console.WriteLine("\t╚══════════════════════════════════════════════════╝");
            Console.ResetColor();
        }

        // Print success message in green
        static void PrintSuccess(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n\t  ✅  {message}");
            Console.ResetColor();
        }

        // Print error message in red
        static void PrintError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\n\t  ❌  {message}");
            Console.ResetColor();
        }

        // Print warning message in yellow
        static void PrintWarning(string message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n\t  ⚠️   {message}");
            Console.ResetColor();
        }

        // Pause screen and wait for user input
        static void PauseScreen()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n\t  Press any key to return to the main menu...");
            Console.ResetColor();
            Console.ReadKey();
        }

        // Loading animation using a loop
        static void ShowLoadingAnimation(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write($"\n\t  {message}");
            string[] frames = { "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏" };
            for (int i = 0; i < 20; i++)
            {
                Console.Write($" {frames[i % frames.Length]}");
                Thread.Sleep(80);
                Console.Write("\b\b");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" ✅");
            Console.ResetColor();
            Thread.Sleep(400);
        }

        // Read password with masking (shows * instead of characters)
        static string ReadPassword()
        {
            Console.WriteLine();
            string password = "";
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(intercept: true); // Don't display the key

                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
                else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
                {
                    // Handle backspace
                    password = password.Substring(0, password.Length - 1);
                    Console.Write("\b \b");
                }
            }
            while (key.Key != ConsoleKey.Enter);

            Console.WriteLine();
            return password;
        }
    }
}
